package app.sonora.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import app.sonora.domain.model.Track

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

/** Cópia local dos dados da música: a playlist continua funcionando mesmo offline. */
@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val artworkUri: String?,
    val mediaUri: String,
    val durationMs: Long,
    val isLocal: Boolean,
)

/** Tabela de ligação N:N entre playlists e músicas. */
@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "trackId"],
    foreignKeys = [
        ForeignKey(PlaylistEntity::class, parentColumns = ["id"], childColumns = ["playlistId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(TrackEntity::class, parentColumns = ["id"], childColumns = ["trackId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("trackId")],
)
data class PlaylistTrackCrossRef(
    val playlistId: Long,
    val trackId: String,
    val addedAt: Long,
)

/** Resultado da query de listagem (não é tabela). */
data class PlaylistWithCount(val id: Long, val name: String, val trackCount: Int)

fun TrackEntity.toDomain() = Track(id, title, artist, album, artworkUri, mediaUri, durationMs, isLocal)

fun Track.toEntity() = TrackEntity(id, title, artist, album, artworkUri, mediaUri, durationMs, isLocal)
