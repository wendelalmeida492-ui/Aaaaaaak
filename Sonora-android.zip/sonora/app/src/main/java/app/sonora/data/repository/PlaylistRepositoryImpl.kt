package app.sonora.data.repository

import app.sonora.data.local.PlaylistDao
import app.sonora.data.local.PlaylistEntity
import app.sonora.data.local.toDomain
import app.sonora.data.local.toEntity
import app.sonora.domain.model.Track
import app.sonora.domain.model.UserPlaylist
import app.sonora.domain.repository.PlaylistRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class PlaylistRepositoryImpl @Inject constructor(
    private val dao: PlaylistDao,
) : PlaylistRepository {

    override fun observePlaylists(): Flow<List<UserPlaylist>> =
        dao.observePlaylists().map { list -> list.map { UserPlaylist(it.id, it.name, it.trackCount) } }

    override fun observeTracks(playlistId: Long): Flow<List<Track>> =
        dao.observeTracks(playlistId).map { list -> list.map { it.toDomain() } }

    override suspend fun create(name: String): Long =
        dao.insertPlaylist(PlaylistEntity(name = name, createdAt = System.currentTimeMillis()))

    override suspend fun rename(id: Long, name: String) = dao.rename(id, name)

    override suspend fun delete(id: Long) = dao.delete(id)

    override suspend fun addTrack(playlistId: Long, track: Track) =
        dao.addTrack(playlistId, track.toEntity())

    override suspend fun removeTrack(playlistId: Long, trackId: String) =
        dao.removeTrack(playlistId, trackId)
}
