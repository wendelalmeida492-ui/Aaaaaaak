package app.sonora.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class PlaylistDao {

    @Query(
        """
        SELECT p.id AS id, p.name AS name,
               (SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = p.id) AS trackCount
        FROM playlists p ORDER BY p.createdAt DESC
        """
    )
    abstract fun observePlaylists(): Flow<List<PlaylistWithCount>>

    @Query(
        """
        SELECT t.* FROM tracks t
        INNER JOIN playlist_tracks pt ON t.id = pt.trackId
        WHERE pt.playlistId = :playlistId ORDER BY pt.addedAt ASC
        """
    )
    abstract fun observeTracks(playlistId: Long): Flow<List<TrackEntity>>

    @Insert
    abstract suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    abstract suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    abstract suspend fun delete(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun upsertTrack(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insertCrossRef(ref: PlaylistTrackCrossRef)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId")
    abstract suspend fun removeTrack(playlistId: Long, trackId: String)

    /** Salva a música e a liga à playlist numa única transação. */
    @Transaction
    open suspend fun addTrack(playlistId: Long, track: TrackEntity) {
        upsertTrack(track)
        insertCrossRef(PlaylistTrackCrossRef(playlistId, track.id, System.currentTimeMillis()))
    }
}
