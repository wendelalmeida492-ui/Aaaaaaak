package app.sonora.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [PlaylistEntity::class, TrackEntity::class, PlaylistTrackCrossRef::class],
    version = 1,
    exportSchema = false,
)
abstract class SonoraDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
}
