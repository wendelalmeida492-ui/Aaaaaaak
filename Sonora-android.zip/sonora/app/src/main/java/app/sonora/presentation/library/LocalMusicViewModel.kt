package app.sonora.presentation.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.sonora.domain.model.Track
import app.sonora.domain.repository.LocalMusicRepository
import app.sonora.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class LocalMusicUiState(
    val isLoading: Boolean = true,
    val hasPermission: Boolean = false,
    val tracks: List<Track> = emptyList(),
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class LocalMusicViewModel @Inject constructor(
    repository: LocalMusicRepository,
    private val player: PlayerController,
) : ViewModel() {

    private val permissionGranted = MutableStateFlow(false)

    /** Só lê o MediaStore quando a permissão está concedida. */
    val uiState: StateFlow<LocalMusicUiState> = permissionGranted
        .flatMapLatest { granted ->
            if (granted) {
                repository.observeTracks().map { LocalMusicUiState(isLoading = false, hasPermission = true, tracks = it) }
            } else {
                flowOf(LocalMusicUiState(isLoading = false, hasPermission = false))
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LocalMusicUiState())

    fun onPermissionChanged(granted: Boolean) { permissionGranted.value = granted }

    fun play(queue: List<Track>, index: Int) = player.play(queue, index)

    fun shuffleAll(tracks: List<Track>) = player.play(tracks.shuffled(), 0)
}
