package app.sonora.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.sonora.domain.model.ThemeMode
import app.sonora.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Deve ser declarado uma única vez, no nível do arquivo.
private val Context.dataStore by preferencesDataStore(name = "settings")

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) : SettingsRepository {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val offlineKey = booleanPreferencesKey("offline_mode")

    override val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        prefs[themeKey]
            ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
            ?: ThemeMode.SYSTEM
    }

    override val offlineMode: Flow<Boolean> = context.dataStore.data.map { it[offlineKey] ?: false }

    override suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    override suspend fun setOfflineMode(enabled: Boolean) {
        context.dataStore.edit { it[offlineKey] = enabled }
    }
}
