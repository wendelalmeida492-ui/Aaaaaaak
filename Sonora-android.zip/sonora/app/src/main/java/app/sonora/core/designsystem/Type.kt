package app.sonora.core.designsystem

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Troque FontFamily.Default por uma fonte própria (res/font) para reforçar a identidade.
val SonoraTypography = Typography(
    headlineMedium = TextStyle(FontFamily.Default, FontWeight.ExtraBold, 30.sp, letterSpacing = (-0.5).sp),
    titleLarge = TextStyle(FontFamily.Default, FontWeight.Bold, 22.sp),
    titleMedium = TextStyle(FontFamily.Default, FontWeight.SemiBold, 16.sp),
    bodyMedium = TextStyle(FontFamily.Default, FontWeight.Normal, 14.sp),
    bodySmall = TextStyle(FontFamily.Default, FontWeight.Normal, 12.sp),
    labelMedium = TextStyle(FontFamily.Default, FontWeight.Medium, 12.sp),
)
