package app.sonora

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/** Ponto de entrada do Hilt. */
@HiltAndroidApp
class SonoraApp : Application()
