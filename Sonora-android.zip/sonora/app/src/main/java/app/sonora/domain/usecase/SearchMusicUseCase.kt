package app.sonora.domain.usecase

import app.sonora.domain.model.SearchResults
import app.sonora.domain.model.toAlbums
import app.sonora.domain.model.toArtists
import app.sonora.domain.repository.LocalMusicRepository
import app.sonora.domain.repository.MusicRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.first

/**
 * Busca no aparelho e, se não estiver offline, também no catálogo.
 * Resultados do aparelho vêm primeiro.
 */
class SearchMusicUseCase @Inject constructor(
    private val musicRepository: MusicRepository,
    private val localRepository: LocalMusicRepository,
) {
    suspend operator fun invoke(query: String, offlineOnly: Boolean): SearchResults {
        val local = searchLocal(query)
        if (offlineOnly) return local

        val remote = musicRepository.search(query)
        return SearchResults(
            tracks = local.tracks + remote.tracks,
            artists = local.artists + remote.artists,
            albums = local.albums + remote.albums,
        )
    }

    private suspend fun searchLocal(query: String): SearchResults {
        val all = localRepository.observeTracks().first()
        fun String.has() = contains(query, ignoreCase = true)
        return SearchResults(
            tracks = all.filter { it.title.has() || it.artist.has() || it.album.has() },
            artists = all.toArtists().filter { it.name.has() },
            albums = all.toAlbums().filter { it.title.has() || it.artist.has() },
        )
    }
}
