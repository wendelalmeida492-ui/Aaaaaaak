package app.sonora.presentation.player

import androidx.lifecycle.ViewModel
import app.sonora.player.PlayerController
import app.sonora.player.PlayerState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.StateFlow

@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val controller: PlayerController,
) : ViewModel() {

    val state: StateFlow<PlayerState> = controller.state

    fun onTogglePlay() = controller.togglePlayPause()
    fun onNext() = controller.next()
    fun onPrevious() = controller.previous()
    fun onSeek(positionMs: Long) = controller.seekTo(positionMs)
    fun onToggleShuffle() = controller.toggleShuffle()
    fun onCycleRepeat() = controller.cycleRepeat()
}
