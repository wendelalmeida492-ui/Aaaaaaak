package app.sonora.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Ink500,
    onPrimary = Color.White,
    secondary = Peach500,
    background = Sand50,
    onBackground = Color(0xFF1C1830),
    surface = Color.White,
    onSurface = Color(0xFF1C1830),
    surfaceVariant = Color(0xFFEDE7F7),
    onSurfaceVariant = Color(0xFF5E5878),
)

private val DarkColors = darkColorScheme(
    primary = Ink200,
    onPrimary = Color(0xFF1E1250),
    secondary = Peach200,
    background = Night900,
    onBackground = Color(0xFFEDE9FA),
    surface = Night800,
    onSurface = Color(0xFFEDE9FA),
    surfaceVariant = Night700,
    onSurfaceVariant = Color(0xFFB9B3D3),
)

/** Tema do app. Sem cor dinâmica de propósito, para manter identidade própria. */
@Composable
fun SonoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = SonoraTypography,
        content = content,
    )
}
