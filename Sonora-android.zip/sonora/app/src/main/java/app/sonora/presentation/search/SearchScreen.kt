package app.sonora.presentation.search

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.sonora.presentation.components.MediaRow

@Composable
fun SearchScreen(
    onOpenPlayer: () -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val query by viewModel.query.collectAsStateWithLifecycle()
    val results by viewModel.results.collectAsStateWithLifecycle()
    val offline by viewModel.offline.collectAsStateWithLifecycle()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Text(
            "Buscar",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp),
        )
        OutlinedTextField(
            value = query,
            onValueChange = viewModel::onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            placeholder = { Text("Músicas, artistas ou álbuns") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.onQueryChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Limpar busca")
                    }
                }
            },
        )
        if (offline) {
            Text(
                "Modo offline: buscando só no aparelho",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 24.dp, bottom = 4.dp),
            )
        }

        when {
            query.isBlank() -> Hint("Encontre suas músicas favoritas")
            results.isEmpty -> Hint("Nada encontrado para \"$query\"")
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                if (results.tracks.isNotEmpty()) {
                    item(key = "h-tracks") { Header("Músicas") }
                    items(results.tracks, key = { "t-${it.id}" }) { track ->
                        MediaRow(
                            title = track.title,
                            subtitle = track.artist,
                            artworkUri = track.artworkUri,
                            onClick = {
                                viewModel.onTrackClick(track, results.tracks)
                                onOpenPlayer()
                            },
                        )
                    }
                }
                if (results.artists.isNotEmpty()) {
                    item(key = "h-artists") { Header("Artistas") }
                    items(results.artists, key = { "a-${it.id}" }) { artist ->
                        MediaRow(
                            title = artist.name, subtitle = "Artista",
                            artworkUri = artist.imageUri, circular = true,
                            onClick = { /* TODO: perfil do artista */ },
                        )
                    }
                }
                if (results.albums.isNotEmpty()) {
                    item(key = "h-albums") { Header("Álbuns") }
                    items(results.albums, key = { "al-${it.id}" }) { album ->
                        MediaRow(
                            title = album.title, subtitle = album.artist,
                            artworkUri = album.artworkUri,
                            onClick = { /* TODO: detalhe do álbum */ },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun Hint(text: String) {
    Box(Modifier.fillMaxSize().padding(top = 48.dp), contentAlignment = Alignment.TopCenter) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
