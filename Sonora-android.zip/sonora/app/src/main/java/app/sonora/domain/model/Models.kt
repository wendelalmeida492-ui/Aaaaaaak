package app.sonora.domain.model

/** Música. Pode ser local (MediaStore) ou remota (stream). */
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val artworkUri: String?,
    val mediaUri: String,
    val durationMs: Long,
    val isLocal: Boolean = false,
)

data class Artist(val id: String, val name: String, val imageUri: String?)

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUri: String?,
)

data class Playlist(
    val id: String,
    val name: String,
    val trackCount: Int,
    val coverUri: String? = null,
)

/** Tudo que a tela inicial precisa, num único objeto. */
data class HomeFeed(
    val recent: List<Track> = emptyList(),
    /** Músicas do aparelho (MediaStore). */
    val localTracks: List<Track> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
    val isOffline: Boolean = false,
)

/** Playlist criada pelo usuário (salva no Room, por isso id numérico). */
data class UserPlaylist(val id: Long, val name: String, val trackCount: Int)

data class SearchResults(
    val tracks: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
) {
    val isEmpty: Boolean get() = tracks.isEmpty() && artists.isEmpty() && albums.isEmpty()
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }
