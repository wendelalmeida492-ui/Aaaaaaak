package app.sonora.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.sonora.domain.model.Track
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class RepeatMode { OFF, ALL, ONE }

/** Estado imutável do player, observado pela UI. */
data class PlayerState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
)

/**
 * Ponte entre a UI e o [PlaybackService].
 *
 * Em vez de criar um ExoPlayer, conecta-se à MediaSession do serviço por meio de um
 * MediaController (que implementa a mesma interface Player). Assim o áudio sobrevive
 * ao app ser fechado, e ao reabrir o app o estado atual é restaurado.
 *
 * Todos os dados da música viajam dentro do MediaItem (metadados + extras), então o
 * estado nunca depende de uma lista guardada na memória deste objeto.
 *
 * Deve ser criado na main thread (o Hilt já faz isso ao injetar em ViewModels).
 */
@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var controller: MediaController? = null
    private val pending = mutableListOf<(MediaController) -> Unit>()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                val connected = runCatching { future.get() }.getOrNull() ?: return@addListener
                connected.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = publish()
                })
                controller = connected
                // Executa comandos que chegaram antes da conexão ficar pronta.
                pending.forEach { it(connected) }
                pending.clear()
                publish()
            },
            ContextCompat.getMainExecutor(context),
        )

        // Atualiza a posição a cada 500 ms enquanto toca.
        scope.launch {
            while (true) {
                if (controller?.isPlaying == true) publish()
                delay(500)
            }
        }
    }

    /** Executa já, se conectado; senão, assim que a conexão com o serviço abrir. */
    private fun whenReady(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending += block
    }

    fun play(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        val (window, start) = windowAround(tracks, startIndex.coerceIn(0, tracks.lastIndex))
        whenReady { c ->
            c.setMediaItems(window.map { it.toMediaItem() }, start, 0L)
            c.prepare()
            c.play()
        }
    }

    fun togglePlayPause() = whenReady { if (it.isPlaying) it.pause() else it.play() }
    fun next() = whenReady { it.seekToNextMediaItem() }
    fun previous() = whenReady { it.seekToPrevious() } // volta ao início se passou de ~3 s
    fun seekTo(positionMs: Long) = whenReady { it.seekTo(positionMs) }

    fun toggleShuffle() = whenReady { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    /** Alterna OFF -> ALL -> ONE -> OFF. */
    fun cycleRepeat() = whenReady {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun publish() {
        val c = controller ?: return
        val current = c.currentMediaItem?.toTrack()
        _state.value = PlayerState(
            currentTrack = current,
            isPlaying = c.isPlaying,
            isBuffering = c.playbackState == Player.STATE_BUFFERING,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET } ?: current?.durationMs ?: 0L,
            shuffleEnabled = c.shuffleModeEnabled,
            repeatMode = when (c.repeatMode) {
                Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                else -> RepeatMode.OFF
            },
            hasNext = c.hasNextMediaItem(),
            hasPrevious = c.hasPreviousMediaItem(),
        )
    }

    /**
     * Mandar milhares de itens de uma vez pode estourar o limite do Binder (~1 MB).
     * Para listas grandes (ex.: biblioteca local) enviamos só uma janela ao redor da música tocada.
     */
    private fun windowAround(tracks: List<Track>, index: Int): Pair<List<Track>, Int> {
        if (tracks.size <= MAX_QUEUE) return tracks to index
        var from = (index - MAX_QUEUE / 2).coerceAtLeast(0)
        val to = (from + MAX_QUEUE).coerceAtMost(tracks.size)
        from = (to - MAX_QUEUE).coerceAtLeast(0)
        return tracks.subList(from, to) to (index - from)
    }

    private companion object {
        const val MAX_QUEUE = 250
        const val KEY_URI = "sonora.mediaUri"
        const val KEY_LOCAL = "sonora.isLocal"
    }

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(mediaUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artworkUri?.let(Uri::parse))
                .setDurationMs(durationMs.takeIf { it > 0 })
                .setIsPlayable(true)
                .setIsBrowsable(false)
                .setExtras(Bundle().apply {
                    putString(KEY_URI, mediaUri)
                    putBoolean(KEY_LOCAL, isLocal)
                })
                .build()
        )
        .build()

    private fun MediaItem.toTrack(): Track {
        val meta = mediaMetadata
        val extras = meta.extras
        return Track(
            id = mediaId,
            title = meta.title?.toString().orEmpty(),
            artist = meta.artist?.toString().orEmpty(),
            album = meta.albumTitle?.toString().orEmpty(),
            artworkUri = meta.artworkUri?.toString(),
            mediaUri = extras?.getString(KEY_URI) ?: localConfiguration?.uri?.toString().orEmpty(),
            durationMs = meta.durationMs ?: 0L,
            isLocal = extras?.getBoolean(KEY_LOCAL) ?: false,
        )
    }
}
