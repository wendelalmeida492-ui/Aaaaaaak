package app.sonora.presentation.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.sonora.domain.model.UserPlaylist
import app.sonora.domain.repository.PlaylistRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repository: PlaylistRepository,
) : ViewModel() {

    val playlists: StateFlow<List<UserPlaylist>> = repository.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun create(name: String) { viewModelScope.launch { repository.create(name) } }
    fun rename(id: Long, name: String) { viewModelScope.launch { repository.rename(id, name) } }
    fun delete(id: Long) { viewModelScope.launch { repository.delete(id) } }
}
