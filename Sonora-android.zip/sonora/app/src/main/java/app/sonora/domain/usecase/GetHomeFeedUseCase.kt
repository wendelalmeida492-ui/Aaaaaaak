package app.sonora.domain.usecase

import app.sonora.domain.model.HomeFeed
import app.sonora.domain.model.toAlbums
import app.sonora.domain.model.toArtists
import app.sonora.domain.repository.LocalMusicRepository
import app.sonora.domain.repository.MusicRepository
import app.sonora.domain.repository.SettingsRepository
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/**
 * Monta a Home.
 * - Online: catálogo + uma seção com as músicas do aparelho.
 * - Offline: ignora o catálogo e deriva tudo (músicas, artistas, álbuns) do aparelho.
 */
class GetHomeFeedUseCase @Inject constructor(
    private val musicRepository: MusicRepository,
    private val localRepository: LocalMusicRepository,
    private val settings: SettingsRepository,
) {
    private fun catalogFeed(): Flow<HomeFeed> = combine(
        musicRepository.observeRecentTracks(),
        musicRepository.observeRecommendedPlaylists(),
        musicRepository.observeArtists(),
        musicRepository.observeAlbums(),
    ) { recent, playlists, artists, albums ->
        HomeFeed(recent = recent, playlists = playlists, artists = artists, albums = albums)
    }

    operator fun invoke(): Flow<HomeFeed> = combine(
        catalogFeed(),
        localRepository.observeTracks(),
        settings.offlineMode,
    ) { catalog, local, offline ->
        if (offline) {
            HomeFeed(
                localTracks = local.take(HOME_LIMIT),
                artists = local.toArtists().take(HOME_LIMIT),
                albums = local.toAlbums().take(HOME_LIMIT),
                isOffline = true,
            )
        } else {
            catalog.copy(localTracks = local.take(HOME_LIMIT))
        }
    }

    private companion object {
        const val HOME_LIMIT = 30 // carrosséis curtos; a lista completa fica na Biblioteca
    }
}
