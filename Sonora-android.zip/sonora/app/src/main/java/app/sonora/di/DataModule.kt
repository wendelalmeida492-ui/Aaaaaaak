package app.sonora.di

import app.sonora.data.preferences.UserPreferencesRepository
import app.sonora.data.repository.MediaStoreMusicRepository
import app.sonora.data.repository.PlaylistRepositoryImpl
import app.sonora.data.repository.SampleMusicRepository
import app.sonora.domain.repository.LocalMusicRepository
import app.sonora.domain.repository.MusicRepository
import app.sonora.domain.repository.PlaylistRepository
import app.sonora.domain.repository.SettingsRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class DataModule {
    // Troque SampleMusicRepository pela implementação real quando ela existir.
    @Binds @Singleton
    abstract fun bindMusicRepository(impl: SampleMusicRepository): MusicRepository

    @Binds @Singleton
    abstract fun bindPlaylistRepository(impl: PlaylistRepositoryImpl): PlaylistRepository

    @Binds @Singleton
    abstract fun bindLocalMusicRepository(impl: MediaStoreMusicRepository): LocalMusicRepository

    @Binds @Singleton
    abstract fun bindSettingsRepository(impl: UserPreferencesRepository): SettingsRepository
}
