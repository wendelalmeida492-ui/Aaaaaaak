package app.sonora.presentation.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.sonora.player.PlayerState
import app.sonora.presentation.components.AddToPlaylistSheet
import app.sonora.player.RepeatMode
import coil.compose.AsyncImage

/** Player em tela cheia. */
@Composable
fun PlayerScreen(
    onBack: () -> Unit,
    viewModel: PlayerViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var showPlaylistSheet by remember { mutableStateOf(false) }

    PlayerContent(
        state = state,
        onBack = onBack,
        onAddToPlaylist = { showPlaylistSheet = true },
        onTogglePlay = viewModel::onTogglePlay,
        onNext = viewModel::onNext,
        onPrevious = viewModel::onPrevious,
        onSeek = viewModel::onSeek,
        onToggleShuffle = viewModel::onToggleShuffle,
        onCycleRepeat = viewModel::onCycleRepeat,
    )

    val track = state.currentTrack
    if (showPlaylistSheet && track != null) {
        AddToPlaylistSheet(track = track, onDismiss = { showPlaylistSheet = false })
    }
}

@Composable
private fun PlayerContent(
    state: PlayerState,
    onBack: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val track = state.currentTrack

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(colors.primary.copy(alpha = 0.30f), colors.background, colors.background)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
    ) {
        // Barra superior
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Fechar player", Modifier.size(32.dp))
            }
            Text(
                "Tocando agora",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                color = colors.onBackground,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.size(48.dp)) // equilibra o botão da esquerda
        }

        if (track == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Nada tocando", color = colors.onSurfaceVariant)
            }
            return@Column
        }

        Spacer(Modifier.height(16.dp))

        // Capa grande: "respira" um pouco quando pausa/toca
        val artScale by animateFloatAsState(
            targetValue = if (state.isPlaying) 1f else 0.90f,
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 200f),
            label = "artScale",
        )
        AsyncImage(
            model = track.artworkUri,
            contentDescription = "Capa de ${track.album}",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .graphicsLayer { scaleX = artScale; scaleY = artScale }
                .shadow(24.dp, RoundedCornerShape(32.dp))
                .clip(RoundedCornerShape(32.dp))
                .background(colors.surfaceVariant),
        )

        Spacer(Modifier.height(32.dp))

        // Título, artista e "adicionar à playlist"
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    track.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleLarge, color = colors.onBackground,
                )
                Text(
                    track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, color = colors.onSurfaceVariant,
                )
            }
            IconButton(onClick = onAddToPlaylist) {
                Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, contentDescription = "Adicionar à playlist", Modifier.size(28.dp))
            }
        }

        Spacer(Modifier.height(16.dp))

        SeekBar(positionMs = state.positionMs, durationMs = state.durationMs, onSeek = onSeek)

        Spacer(Modifier.height(8.dp))

        // Controles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onToggleShuffle) {
                Icon(
                    Icons.Rounded.Shuffle, contentDescription = "Aleatório",
                    tint = if (state.shuffleEnabled) colors.primary else colors.onSurfaceVariant,
                )
            }
            IconButton(onClick = onPrevious, enabled = true) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = "Anterior", Modifier.size(40.dp))
            }
            FilledIconButton(onClick = onTogglePlay, modifier = Modifier.size(76.dp)) {
                if (state.isBuffering) {
                    CircularProgressIndicator(
                        Modifier.size(32.dp), strokeWidth = 3.dp, color = colors.onPrimary,
                    )
                } else {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (state.isPlaying) "Pausar" else "Tocar",
                        modifier = Modifier.size(40.dp),
                    )
                }
            }
            IconButton(onClick = onNext, enabled = state.hasNext || state.repeatMode == RepeatMode.ALL) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Próxima", Modifier.size(40.dp))
            }
            IconButton(onClick = onCycleRepeat) {
                Icon(
                    imageVector = if (state.repeatMode == RepeatMode.ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    contentDescription = "Repetir",
                    tint = if (state.repeatMode == RepeatMode.OFF) colors.onSurfaceVariant else colors.primary,
                )
            }
        }

        Spacer(Modifier.weight(1f))
    }
}

/**
 * Barra de progresso com seek. Enquanto o dedo arrasta, mostramos o valor local;
 * o seek real só acontece ao soltar (evita "pulos" e chamadas em excesso ao player).
 */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit) {
    var dragValue by remember { mutableStateOf<Float?>(null) }
    val progress = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shownPosition = dragValue?.let { (it * durationMs).toLong() } ?: positionMs

    Column {
        Slider(
            value = dragValue ?: progress,
            onValueChange = { dragValue = it },
            onValueChangeFinished = {
                dragValue?.let { onSeek((it * durationMs).toLong()) }
                dragValue = null
            },
            enabled = durationMs > 0,
            colors = SliderDefaults.colors(
                inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
            ),
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(formatTime(durationMs), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
