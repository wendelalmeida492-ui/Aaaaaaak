package app.sonora.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.sonora.domain.model.SearchResults
import app.sonora.domain.model.Track
import app.sonora.domain.repository.SettingsRepository
import app.sonora.domain.usecase.SearchMusicUseCase
import app.sonora.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val searchMusic: SearchMusicUseCase,
    settings: SettingsRepository,
    private val player: PlayerController,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val offline: StateFlow<Boolean> = settings.offlineMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    /**
     * Espera 250 ms sem digitação, refaz a busca se o modo offline mudar
     * e cancela buscas antigas (mapLatest).
     */
    val results: StateFlow<SearchResults> = combine(
        _query.debounce(250).distinctUntilChanged(),
        settings.offlineMode,
    ) { query, offline -> query to offline }
        .mapLatest { (query, offline) ->
            if (query.isBlank()) SearchResults() else searchMusic(query.trim(), offline)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchResults())

    fun onQueryChange(value: String) { _query.value = value }

    fun onTrackClick(track: Track, queue: List<Track>) {
        player.play(queue, queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0))
    }
}
