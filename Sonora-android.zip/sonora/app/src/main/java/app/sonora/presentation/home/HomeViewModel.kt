package app.sonora.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.sonora.domain.model.HomeFeed
import app.sonora.domain.model.Track
import app.sonora.domain.usecase.GetHomeFeedUseCase
import app.sonora.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class HomeUiState(
    val isLoading: Boolean = true,
    val feed: HomeFeed = HomeFeed(),
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    getHomeFeed: GetHomeFeedUseCase,
    private val player: PlayerController,
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = getHomeFeed()
        .map { HomeUiState(isLoading = false, feed = it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    /** Toca a música clicada usando a lista da seção como fila. */
    fun onTrackClick(track: Track, queue: List<Track>) {
        player.play(queue, queue.indexOfFirst { it.id == track.id }.coerceAtLeast(0))
    }
}
