package app.sonora.domain.model

/** Álbuns derivados das músicas do aparelho (agrupa por álbum + artista). */
fun List<Track>.toAlbums(): List<Album> =
    groupBy { it.album to it.artist }
        .map { (key, tracks) ->
            Album(
                id = "local-album:${key.first}:${key.second}",
                title = key.first,
                artist = key.second,
                artworkUri = tracks.first().artworkUri,
            )
        }
        .sortedBy { it.title.lowercase() }

/** Artistas derivados das músicas do aparelho (usa a capa da primeira faixa como imagem). */
fun List<Track>.toArtists(): List<Artist> =
    groupBy { it.artist }
        .map { (name, tracks) ->
            Artist(id = "local-artist:$name", name = name, imageUri = tracks.first().artworkUri)
        }
        .sortedBy { it.name.lowercase() }
