package app.sonora.presentation.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.sonora.domain.model.UserPlaylist
import app.sonora.presentation.components.PlaylistCover
import app.sonora.presentation.components.PlaylistNameDialog

private enum class LibrarySection { PLAYLISTS, DEVICE }

@Composable
fun LibraryScreen(
    onOpenPlaylist: (Long) -> Unit,
    onOpenPlayer: () -> Unit,
    viewModel: LibraryViewModel = hiltViewModel(),
) {
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    var section by rememberSaveable { mutableStateOf(LibrarySection.PLAYLISTS) }
    var showCreate by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<UserPlaylist?>(null) }
    var deleting by remember { mutableStateOf<UserPlaylist?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 24.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Biblioteca",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f),
            )
            if (section == LibrarySection.PLAYLISTS) {
                FilledTonalButton(onClick = { showCreate = true }) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Nova")
                }
            }
        }

        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = section == LibrarySection.PLAYLISTS,
                onClick = { section = LibrarySection.PLAYLISTS },
                label = { Text("Playlists") },
            )
            FilterChip(
                selected = section == LibrarySection.DEVICE,
                onClick = { section = LibrarySection.DEVICE },
                label = { Text("No aparelho") },
            )
        }

        when (section) {
            LibrarySection.PLAYLISTS -> PlaylistsList(
                playlists = playlists,
                onOpen = onOpenPlaylist,
                onRename = { renaming = it },
                onDelete = { deleting = it },
            )
            LibrarySection.DEVICE -> LocalMusicSection(onOpenPlayer = onOpenPlayer)
        }
    }

    if (showCreate) {
        PlaylistNameDialog(
            title = "Nova playlist", confirmLabel = "Criar",
            onConfirm = { viewModel.create(it); showCreate = false },
            onDismiss = { showCreate = false },
        )
    }
    renaming?.let { target ->
        PlaylistNameDialog(
            title = "Renomear playlist", confirmLabel = "Salvar", initial = target.name,
            onConfirm = { viewModel.rename(target.id, it); renaming = null },
            onDismiss = { renaming = null },
        )
    }
    deleting?.let { target ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Excluir playlist?") },
            text = { Text("\"${target.name}\" será removida. As músicas não são apagadas do aparelho.") },
            confirmButton = {
                TextButton(onClick = { viewModel.delete(target.id); deleting = null }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun PlaylistsList(
    playlists: List<UserPlaylist>,
    onOpen: (Long) -> Unit,
    onRename: (UserPlaylist) -> Unit,
    onDelete: (UserPlaylist) -> Unit,
) {
    if (playlists.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
            Text(
                "Você ainda não tem playlists.\nToque em \"Nova\" para criar a primeira.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
            items(playlists, key = { it.id }) { playlist ->
                PlaylistRow(
                    playlist = playlist,
                    onClick = { onOpen(playlist.id) },
                    onRename = { onRename(playlist) },
                    onDelete = { onDelete(playlist) },
                )
            }
        }
    }
}

@Composable
private fun PlaylistRow(
    playlist: UserPlaylist,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlaylistCover(seed = playlist.id)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                playlist.name, maxLines = 1,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                "${playlist.trackCount} músicas",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Mais opções")
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(text = { Text("Renomear") }, onClick = { menuOpen = false; onRename() })
                DropdownMenuItem(text = { Text("Excluir") }, onClick = { menuOpen = false; onDelete() })
            }
        }
    }
}
