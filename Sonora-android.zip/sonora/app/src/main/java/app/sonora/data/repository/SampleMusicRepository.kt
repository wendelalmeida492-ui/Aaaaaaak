package app.sonora.data.repository

import app.sonora.domain.model.Album
import app.sonora.domain.model.Artist
import app.sonora.domain.model.Playlist
import app.sonora.domain.model.SearchResults
import app.sonora.domain.model.Track
import app.sonora.domain.repository.MusicRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Repositório de EXEMPLO, só para o app rodar de primeira.
 * Áudio: SoundHelix (músicas de demonstração gratuitas). Imagens: picsum.photos.
 * Substitua por uma implementação real (fonte remota + MediaStore).
 */
@Singleton
class SampleMusicRepository @Inject constructor() : MusicRepository {

    private fun art(seed: String) = "https://picsum.photos/seed/$seed/600"

    private val tracks = (1..8).map { n ->
        Track(
            id = "t$n",
            title = "Faixa de demonstração $n",
            artist = "Artista ${(n - 1) % 4 + 1}",
            album = "Álbum ${(n - 1) % 3 + 1}",
            artworkUri = art("track$n"),
            mediaUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-$n.mp3",
            durationMs = 0L, // o ExoPlayer informa a duração real
        )
    }

    private val playlists = listOf(
        Playlist("p1", "Foco profundo", 24),
        Playlist("p2", "Estrada à noite", 18),
        Playlist("p3", "Manhã leve", 31),
        Playlist("p4", "Treino", 40),
    )

    private val artists = (1..6).map { Artist("a$it", "Artista $it", art("artist$it")) }

    private val albums = (1..6).map {
        Album("al$it", "Álbum $it", "Artista ${(it - 1) % 4 + 1}", art("album$it"))
    }

    override fun observeRecentTracks(): Flow<List<Track>> = flowOf(tracks)
    override fun observeRecommendedPlaylists(): Flow<List<Playlist>> = flowOf(playlists)
    override fun observeArtists(): Flow<List<Artist>> = flowOf(artists)
    override fun observeAlbums(): Flow<List<Album>> = flowOf(albums)

    override suspend fun search(query: String): SearchResults {
        fun String.has() = contains(query, ignoreCase = true)
        return SearchResults(
            tracks = tracks.filter { it.title.has() || it.artist.has() || it.album.has() },
            artists = artists.filter { it.name.has() },
            albums = albums.filter { it.title.has() || it.artist.has() },
        )
    }
}
