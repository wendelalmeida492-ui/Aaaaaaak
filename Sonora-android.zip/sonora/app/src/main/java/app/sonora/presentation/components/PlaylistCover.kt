package app.sonora.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private val coverGradients = listOf(
    listOf(Color(0xFF5B3FD9), Color(0xFFB6A4FF)),
    listOf(Color(0xFFE2663F), Color(0xFFFFB199)),
    listOf(Color(0xFF1F8A8A), Color(0xFF9BE3D0)),
    listOf(Color(0xFF8A3FD9), Color(0xFFFF8AD0)),
)

/** Capa gerada para playlists do usuário (degradê estável a partir do id). */
@Composable
fun PlaylistCover(seed: Long, size: Dp = 52.dp, modifier: Modifier = Modifier) {
    val colors = coverGradients[(seed % coverGradients.size).toInt().coerceAtLeast(0)]
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Rounded.LibraryMusic, contentDescription = null,
            tint = Color.White.copy(alpha = 0.9f),
            modifier = Modifier.size(size / 2),
        )
    }
}
