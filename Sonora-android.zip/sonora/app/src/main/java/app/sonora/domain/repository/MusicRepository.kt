package app.sonora.domain.repository

import app.sonora.domain.model.Album
import app.sonora.domain.model.Artist
import app.sonora.domain.model.Playlist
import app.sonora.domain.model.SearchResults
import app.sonora.domain.model.Track
import kotlinx.coroutines.flow.Flow

/**
 * Contrato do catálogo de músicas. A implementação final combina a fonte remota,
 * o cache em Room (offline) e o MediaStore (biblioteca local).
 */
interface MusicRepository {
    fun observeRecentTracks(): Flow<List<Track>>
    fun observeRecommendedPlaylists(): Flow<List<Playlist>>
    fun observeArtists(): Flow<List<Artist>>
    fun observeAlbums(): Flow<List<Album>>
    suspend fun search(query: String): SearchResults
}
