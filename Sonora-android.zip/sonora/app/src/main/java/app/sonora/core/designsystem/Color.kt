package app.sonora.core.designsystem

import androidx.compose.ui.graphics.Color

// Paleta própria "Sonora": índigo-tinta + pêssego sobre areia/noite.
val Ink500 = Color(0xFF5B3FD9)
val Ink200 = Color(0xFFB6A4FF)
val Peach500 = Color(0xFFE2663F)
val Peach200 = Color(0xFFFFA98A)

val Sand50 = Color(0xFFFBF8F4)
val Night900 = Color(0xFF12101C)
val Night800 = Color(0xFF1B1830)
val Night700 = Color(0xFF2A2644)
