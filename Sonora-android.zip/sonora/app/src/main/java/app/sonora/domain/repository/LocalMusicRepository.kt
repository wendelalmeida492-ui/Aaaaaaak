package app.sonora.domain.repository

import app.sonora.domain.model.Track
import kotlinx.coroutines.flow.Flow

/** Músicas que já estão no aparelho do usuário. */
interface LocalMusicRepository {
    /** Emite a lista atual e uma nova lista sempre que o MediaStore mudar. */
    fun observeTracks(): Flow<List<Track>>
}
