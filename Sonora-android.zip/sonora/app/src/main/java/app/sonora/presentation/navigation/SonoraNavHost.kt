package app.sonora.presentation.navigation

import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.sonora.presentation.home.HomeScreen
import app.sonora.presentation.library.LibraryScreen
import app.sonora.presentation.library.PlaylistDetailScreen
import app.sonora.presentation.player.MiniPlayer
import app.sonora.presentation.player.PlayerScreen
import app.sonora.presentation.player.PlayerViewModel
import app.sonora.presentation.profile.ProfileScreen
import app.sonora.presentation.search.SearchScreen

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val PROFILE = "profile"
    const val PLAYER = "player"
    const val PLAYLIST = "playlist/{id}"
    fun playlist(id: Long) = "playlist/$id"
}

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    HOME(Routes.HOME, "Início", Icons.Rounded.Home),
    SEARCH(Routes.SEARCH, "Buscar", Icons.Rounded.Search),
    LIBRARY(Routes.LIBRARY, "Biblioteca", Icons.Rounded.LibraryMusic),
    PROFILE(Routes.PROFILE, "Perfil", Icons.Rounded.Person),
}

/** Grafo principal: 4 abas + player em tela cheia + detalhe de playlist. */
@Composable
fun SonoraNavHost(playerViewModel: PlayerViewModel = hiltViewModel()) {
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route
    val playerState by playerViewModel.state.collectAsStateWithLifecycle()

    fun openPlayer() = nav.navigate(Routes.PLAYER) { launchSingleTop = true }

    Scaffold(
        // As telas tratam a barra de status sozinhas; a NavigationBar trata a de navegação.
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (route != Routes.PLAYER) {
                Column(Modifier.background(MaterialTheme.colorScheme.surface)) {
                    MiniPlayer(
                        state = playerState,
                        onClick = ::openPlayer,
                        onTogglePlay = playerViewModel::onTogglePlay,
                        onNext = playerViewModel::onNext,
                    )
                    NavigationBar {
                        Tab.entries.forEach { tab ->
                            val selected = route == tab.route ||
                                (tab == Tab.LIBRARY && route?.startsWith("playlist") == true)
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = tab.label) },
                                label = { Text(tab.label) },
                            )
                        }
                    }
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Routes.HOME) { HomeScreen(onOpenPlayer = ::openPlayer) }
            composable(Routes.SEARCH) { SearchScreen(onOpenPlayer = ::openPlayer) }
            composable(Routes.LIBRARY) {
                LibraryScreen(
                    onOpenPlaylist = { nav.navigate(Routes.playlist(it)) },
                    onOpenPlayer = ::openPlayer,
                )
            }
            composable(Routes.PROFILE) { ProfileScreen() }
            composable(
                route = Routes.PLAYLIST,
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) {
                PlaylistDetailScreen(
                    onBack = { nav.popBackStack() },
                    onOpenPlayer = ::openPlayer,
                )
            }
            composable(
                route = Routes.PLAYER,
                enterTransition = { slideInVertically { it } },
                exitTransition = { slideOutVertically { it } },
                popExitTransition = { slideOutVertically { it } },
            ) {
                PlayerScreen(onBack = { nav.popBackStack() })
            }
        }
    }
}
