package app.sonora.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import app.sonora.domain.model.Track
import app.sonora.domain.repository.LocalMusicRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

/**
 * Lê as músicas do aparelho pelo MediaStore (sem acessar caminhos de arquivo, só content://).
 * Exige a permissão de áudio; sem ela a consulta devolve lista vazia.
 */
@Singleton
class MediaStoreMusicRepository @Inject constructor(
    @ApplicationContext context: Context,
) : LocalMusicRepository {

    private val resolver: ContentResolver = context.contentResolver
    private val collection: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

    override fun observeTracks(): Flow<List<Track>> = callbackFlow {
        // Cada mudança no MediaStore (música nova, apagada, renomeada) dispara uma nova leitura.
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        resolver.registerContentObserver(collection, true, observer)
        trySend(Unit) // leitura inicial
        awaitClose { resolver.unregisterContentObserver(observer) }
    }
        .conflate()
        .map { queryTracks() }
        .flowOn(Dispatchers.IO)

    private fun queryTracks(): List<Track> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
        )
        // Só músicas (ignora toques/alarmes/gravações) com pelo menos 30 s.
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        val args = arrayOf(MIN_DURATION_MS.toString())

        val tracks = mutableListOf<Track>()
        try {
            resolver.query(collection, projection, selection, args, null)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    tracks += Track(
                        // Prefixo evita colisão com ids de outras fontes (ex.: playlists no Room).
                        id = "local:$id",
                        title = c.getString(titleCol).orUnknown("Sem título"),
                        artist = c.getString(artistCol).orUnknown("Artista desconhecido"),
                        album = c.getString(albumCol).orUnknown("Álbum desconhecido"),
                        artworkUri = ContentUris.withAppendedId(ALBUM_ART_URI, c.getLong(albumIdCol)).toString(),
                        mediaUri = ContentUris.withAppendedId(collection, id).toString(),
                        durationMs = c.getLong(durationCol),
                        isLocal = true,
                    )
                }
            }
        } catch (_: SecurityException) {
            // Permissão negada/revogada: a UI já mostra o pedido de permissão.
            return emptyList()
        }
        return tracks.sortedBy { it.title.lowercase() }
    }

    private fun String?.orUnknown(fallback: String): String =
        if (this.isNullOrBlank() || this == "<unknown>") fallback else this

    private companion object {
        const val MIN_DURATION_MS = 30_000L
        // Capas de álbum. Em alguns aparelhos Android 10+ pode não carregar: a UI mostra um placeholder.
        val ALBUM_ART_URI: Uri = Uri.parse("content://media/external/audio/albumart")
    }
}
