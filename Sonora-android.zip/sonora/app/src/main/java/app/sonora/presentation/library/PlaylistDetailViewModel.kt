package app.sonora.presentation.library

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.sonora.domain.model.Track
import app.sonora.domain.model.UserPlaylist
import app.sonora.domain.repository.PlaylistRepository
import app.sonora.domain.repository.SettingsRepository
import app.sonora.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@HiltViewModel
class PlaylistDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: PlaylistRepository,
    settings: SettingsRepository,
    private val player: PlayerController,
) : ViewModel() {

    // "id" vem do argumento da rota "playlist/{id}"
    private val playlistId: Long = checkNotNull(savedStateHandle.get<Long>("id"))

    val playlist: StateFlow<UserPlaylist?> = repository.observePlaylists()
        .map { list -> list.firstOrNull { it.id == playlistId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val tracks: StateFlow<List<Track>> = repository.observeTracks(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val offline: StateFlow<Boolean> = settings.offlineMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    fun play(queue: List<Track>, startIndex: Int) = player.play(queue, startIndex)

    fun remove(trackId: String) {
        viewModelScope.launch { repository.removeTrack(playlistId, trackId) }
    }
}
