package app.sonora.domain.repository

import app.sonora.domain.model.Track
import app.sonora.domain.model.UserPlaylist
import kotlinx.coroutines.flow.Flow

/** CRUD das playlists do usuário. */
interface PlaylistRepository {
    fun observePlaylists(): Flow<List<UserPlaylist>>
    fun observeTracks(playlistId: Long): Flow<List<Track>>
    suspend fun create(name: String): Long
    suspend fun rename(id: Long, name: String)
    suspend fun delete(id: Long)
    suspend fun addTrack(playlistId: Long, track: Track)
    suspend fun removeTrack(playlistId: Long, trackId: String)
}
