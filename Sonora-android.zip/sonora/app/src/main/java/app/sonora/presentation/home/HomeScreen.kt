package app.sonora.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.sonora.domain.model.Album
import app.sonora.domain.model.Artist
import app.sonora.domain.model.Playlist
import app.sonora.domain.model.Track
import coil.compose.AsyncImage
import java.time.LocalTime
import kotlin.math.abs

/** Tela inicial. Fica "burra": só renderiza o estado e repassa eventos. */
@Composable
fun HomeScreen(
    onOpenPlayer: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    HomeContent(
        state = state,
        onTrackClick = { track, queue ->
            viewModel.onTrackClick(track, queue)
            onOpenPlayer()
        },
        onPlaylistClick = { /* TODO: abrir detalhe da playlist */ },
        onArtistClick = { /* TODO: abrir perfil do artista */ },
        onAlbumClick = { /* TODO: abrir detalhe do álbum */ },
    )
}

@Composable
private fun HomeContent(
    state: HomeUiState,
    onTrackClick: (Track, List<Track>) -> Unit,
    onPlaylistClick: (Playlist) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onAlbumClick: (Album) -> Unit,
) {
    val feed = state.feed

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (state.isLoading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
            return@Box
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(top = 24.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp),
        ) {
            item { Header() }

            if (feed.isOffline) {
                item { OfflineBanner(isEmpty = feed.localTracks.isEmpty()) }
            }
            // Seções vazias nem entram na lista (evita espaços em branco no modo offline).
            if (feed.recent.isNotEmpty()) item {
                Section("Ouvidas recentemente", feed.recent, { it.id }) { track ->
                    TrackCard(track, onClick = { onTrackClick(track, feed.recent) })
                }
            }
            if (feed.localTracks.isNotEmpty()) item {
                Section("No seu aparelho", feed.localTracks, { it.id }) { track ->
                    TrackCard(track, onClick = { onTrackClick(track, feed.localTracks) })
                }
            }
            if (feed.playlists.isNotEmpty()) item {
                Section("Playlists recomendadas", feed.playlists, { it.id }) { playlist ->
                    PlaylistCard(playlist, onClick = { onPlaylistClick(playlist) })
                }
            }
            if (feed.artists.isNotEmpty()) item {
                Section("Artistas", feed.artists, { it.id }) { artist ->
                    ArtistItem(artist, onClick = { onArtistClick(artist) })
                }
            }
            if (feed.albums.isNotEmpty()) item {
                Section("Álbuns", feed.albums, { it.id }) { album ->
                    AlbumCard(album, onClick = { onAlbumClick(album) })
                }
            }
        }
    }
}

@Composable
private fun OfflineBanner(isEmpty: Boolean) {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text(
            text = if (isEmpty) {
                "Modo offline ativo, mas não encontramos músicas no aparelho. " +
                    "Abra Biblioteca › No aparelho e permita o acesso."
            } else {
                "Modo offline ativo: mostrando só as músicas do aparelho."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

// ---------- Blocos reutilizáveis ----------

@Composable
private fun Header() {
    Column(Modifier.padding(horizontal = 20.dp)) {
        Text(
            text = greeting(),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text = "O que vamos ouvir hoje?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun greeting(): String = when (LocalTime.now().hour) {
    in 5..11 -> "Bom dia"
    in 12..17 -> "Boa tarde"
    else -> "Boa noite"
}

/** Seção com título + carrossel horizontal. Some se a lista estiver vazia. */
@Composable
private fun <T> Section(
    title: String,
    items: List<T>,
    key: (T) -> String,
    itemContent: @Composable (T) -> Unit,
) {
    if (items.isEmpty()) return
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(12.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            items(items, key = key) { itemContent(it) }
        }
    }
}

@Composable
private fun Artwork(uri: String?, size: Dp, shape: androidx.compose.ui.graphics.Shape) {
    AsyncImage(
        model = uri,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
    )
}

@Composable
private fun CardText(title: String, subtitle: String, width: Dp, center: Boolean = false) {
    val align = if (center) TextAlign.Center else TextAlign.Start
    Column(Modifier.width(width).padding(top = 8.dp)) {
        Text(
            title, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = align,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun TrackCard(track: Track, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)) {
        Artwork(track.artworkUri, 148.dp, RoundedCornerShape(20.dp))
        CardText(track.title, track.artist, 148.dp)
    }
}

@Composable
private fun AlbumCard(album: Album, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)) {
        Artwork(album.artworkUri, 148.dp, RoundedCornerShape(20.dp))
        CardText(album.title, album.artist, 148.dp)
    }
}

@Composable
private fun ArtistItem(artist: Artist, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick),
    ) {
        Artwork(artist.imageUri, 96.dp, CircleShape)
        CardText(artist.name, "Artista", 96.dp, center = true)
    }
}

// Playlists sem capa ganham um degradê estável (derivado do id).
private val playlistGradients = listOf(
    listOf(Color(0xFF5B3FD9), Color(0xFFB6A4FF)),
    listOf(Color(0xFFE2663F), Color(0xFFFFB199)),
    listOf(Color(0xFF1F8A8A), Color(0xFF9BE3D0)),
    listOf(Color(0xFF8A3FD9), Color(0xFFFF8AD0)),
)

@Composable
private fun PlaylistCard(playlist: Playlist, onClick: () -> Unit) {
    val colors = playlistGradients[abs(playlist.id.hashCode()) % playlistGradients.size]
    Column(Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .size(width = 200.dp, height = 120.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(colors))
                .padding(16.dp),
            contentAlignment = Alignment.BottomStart,
        ) {
            Text(
                playlist.name,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                maxLines = 2,
            )
        }
        CardText(playlist.name, "${playlist.trackCount} músicas", 200.dp)
    }
}
