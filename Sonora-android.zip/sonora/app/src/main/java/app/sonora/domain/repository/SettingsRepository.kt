package app.sonora.domain.repository

import app.sonora.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow

/** Preferências do usuário (a implementação usa DataStore). */
interface SettingsRepository {
    val themeMode: Flow<ThemeMode>

    /** Quando ligado, o app só mostra e busca músicas que estão no aparelho. */
    val offlineMode: Flow<Boolean>

    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setOfflineMode(enabled: Boolean)
}
