package app.sonora.domain

import app.sonora.domain.model.Album
import app.sonora.domain.model.Artist
import app.sonora.domain.model.Playlist
import app.sonora.domain.model.SearchResults
import app.sonora.domain.model.Track
import app.sonora.domain.model.toAlbums
import app.sonora.domain.model.toArtists
import app.sonora.domain.repository.LocalMusicRepository
import app.sonora.domain.repository.MusicRepository
import app.sonora.domain.usecase.SearchMusicUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

private fun track(id: String, title: String, artist: String, album: String, local: Boolean = true) =
    Track(id, title, artist, album, "art-$id", "uri-$id", 1_000L, local)

private class FakeCatalog(private val remote: SearchResults) : MusicRepository {
    override fun observeRecentTracks(): Flow<List<Track>> = flowOf(emptyList())
    override fun observeRecommendedPlaylists(): Flow<List<Playlist>> = flowOf(emptyList())
    override fun observeArtists(): Flow<List<Artist>> = flowOf(emptyList())
    override fun observeAlbums(): Flow<List<Album>> = flowOf(emptyList())
    override suspend fun search(query: String): SearchResults = remote
}

private class FakeLocal(private val tracks: List<Track>) : LocalMusicRepository {
    override fun observeTracks(): Flow<List<Track>> = flowOf(tracks)
}

class LocalGroupingTest {
    private val tracks = listOf(
        track("1", "A", "Ana", "Disco 1"),
        track("2", "B", "Ana", "Disco 1"),
        track("3", "C", "Bia", "Disco 2"),
    )

    @Test fun `agrupa albuns por nome e artista`() {
        assertEquals(listOf("Disco 1", "Disco 2"), tracks.toAlbums().map { it.title })
    }

    @Test fun `agrupa artistas sem repetir`() {
        assertEquals(listOf("Ana", "Bia"), tracks.toArtists().map { it.name })
    }
}

class SearchMusicUseCaseTest {
    private val local = listOf(track("local:1", "Samba do aparelho", "Ana", "Disco 1"))
    private val remote = SearchResults(
        tracks = listOf(track("t1", "Samba remoto", "Zé", "Disco R", local = false)),
    )
    private val useCase = SearchMusicUseCase(FakeCatalog(remote), FakeLocal(local))

    @Test fun `offline devolve so musicas do aparelho`() = runTest {
        val result = useCase("samba", offlineOnly = true)
        assertEquals(listOf("local:1"), result.tracks.map { it.id })
    }

    @Test fun `online junta aparelho e catalogo com o aparelho primeiro`() = runTest {
        val result = useCase("samba", offlineOnly = false)
        assertEquals(listOf("local:1", "t1"), result.tracks.map { it.id })
    }

    @Test fun `sem correspondencia devolve vazio no aparelho`() = runTest {
        val result = useCase("rock", offlineOnly = true)
        assertEquals(true, result.isEmpty)
    }
}
