# Sonora

App de música open-source para Android (Kotlin + Jetpack Compose).
Identidade visual própria: índigo-tinta + pêssego.

## Estrutura de pastas

```
app/src/main/java/app/sonora/
├── SonoraApp.kt, MainActivity.kt
├── core/designsystem/        # Color, Type, Theme (claro/escuro)
├── di/                       # DataModule, DatabaseModule (Hilt)
├── domain/
│   ├── model/                # Track, Album, Artist, Playlist, UserPlaylist, ThemeMode...
│   ├── repository/           # MusicRepository, PlaylistRepository
│   └── usecase/              # GetHomeFeedUseCase, SearchMusicUseCase
├── data/
│   ├── local/                # Room: entidades, DAO, banco
│   ├── preferences/          # DataStore (tema)
│   └── repository/           # PlaylistRepositoryImpl, MediaStoreMusicRepository, SampleMusicRepository
├── player/                   # PlaybackService (ExoPlayer + MediaSession) e PlayerController (MediaController)
└── presentation/
    ├── navigation/           # NavHost + barra de 4 abas
    ├── components/           # MediaRow, PlaylistCover, AddToPlaylistSheet...
    ├── home/  search/  library/  profile/  player/ (Player + MiniPlayer)
```

## Status

Feito: modo offline (só músicas do aparelho na Home, busca e playlists), músicas locais na Home e na busca, reprodução em segundo plano com notificação (MediaSessionService), biblioteca local (MediaStore), Início, Player completo, MiniPlayer, 4 abas, Busca, Playlists (criar/renomear/excluir/adicionar/remover, Room), tema claro/escuro/automático (DataStore).

## Rodando

Abra no Android Studio (Ladybug+), sincronize o Gradle e rode.
O repositório de exemplo usa músicas de demonstração (SoundHelix) e imagens do picsum.photos.

## Testes

`gradle testDebugUnitTest` (ou `./gradlew`), com testes de agrupamento local e da busca online/offline.

## Próximos passos

1. Fonte remota real de catálogo
2. Histórico de reprodução ("Ouvidas recentemente" de verdade, via Room)
3. Capas via loadThumbnail (Android 10+)
4. Fila editável e tela de detalhe de álbum/artista
5. Strings em strings.xml

## Gerar o APK (sem Android Studio)

1. Crie um repositório no GitHub e envie estes arquivos (pode ser pelo site: "Add file > Upload files").
2. Abra a aba **Actions > Build APK > Run workflow**.
3. Espere ~5 min, abra a execução e baixe **Sonora-debug-apk** (vem num .zip com o `app-debug.apk`).
4. No celular: permita "instalar apps de fontes desconhecidas" e abra o APK.

Pelo Android Studio: `Build > Build APK(s)`.
